x = ['a','b','c','10','9','8',{'nome':'vitor','email':'vitor@vitor'}]
print (x[6]['email'])
print (type(x))
print (x[::-1])
print (len(x))
nome = 'vitor' 
print (len(nome))
for i in nome:
    print(i)

x,y = '100', 90

print(int(x)+int(y))

