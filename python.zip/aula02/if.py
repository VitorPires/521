n1 = int(input('Digite primeiro numero>> '))
n2 = int(input('Digite segundo numero>> '))
n3 = int(input('Digite terceiro numero>> '))
lista = [n1,n2,n3]
print(max(lista[::]))
#if n1 > n2 :
#   print('Primeiro numero ganha')
#elif n1 > n3:
#   print('Primeiro numero ganha')
#elif n2 > n3:
#      print('Segundo numero ganha')
#else:
#   print('Terceiro numero ganha')

