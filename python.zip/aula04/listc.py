lista = ['1,2,3,4']
print([item for item in range(1,15) if item%2==0])

numbers = [34.6, -203.4, 44.9, 68.3, -12.2, 44.6, 12.7]
print([item for item in numbers[0]])

