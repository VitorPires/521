def imprime(palavra):
  return(palavra.lower())

print(imprime('Vitor'))


