cadastro = [{'nome':'Vitor','senha':1234567}]
for i in cadastro:
  print(i['nome'])
