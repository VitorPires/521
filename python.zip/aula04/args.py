def exemplo(*args):
  print(args)

exemplo('d','a',5)

def dicio(**kwargs):
   print(kwargs)


dicio(nome='vitor',email='vitor@vitor')
