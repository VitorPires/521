# Numericos
x = a,b,c,d,e
print (type(x))
print (x)
