x = 'Python'
print (x.upper())
nome = 'Vitor'
idade = '30'
x = 'Meu nome e' + nome,'e minha idade e'+ idade
