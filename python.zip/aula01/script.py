#!/usr/bin/python3
print ('Hello Word')
while True:
    nome = input ('Qual a melhor linguagem de programacao?')
    if nome == 'python':
        print ('Voce acertou')
        break;
    else:
	print ('Errou')
