x = 1
while x <10:
  if x%2==0:
    print(x)
  x += 1
