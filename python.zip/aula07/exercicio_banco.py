import MySQLdb
con = MySQLdb.connect(
        host="localhost",
        db="projetos",
        user="admin",
        passwd="4linux@"
    )

cur = con.cursor()

opcao = int(input('Escolha opcao: '))
if opcao ==1:
    nome= input('Digite nome ')
    email= input('Digite email')
print()

### INSERT
cur.execute("INSERT INTO clientes(nome,endereco) \
                     VALUES('%s','%s')" %(nome,email)
                )
cur.execute("SELECT * FROM clientes")
registros = cur.fetchall()
print(registros)