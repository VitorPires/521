import os
#import sys
#from datetime import *
#print(os.getlogin())
#print(os.listdir('/tmp'))
#print(os.system('cat /etc/passwd'))
#print(sys.builtin_module_names)
#print(sys.argv)
#print(datetime.now())

#print(timedelta(7))
#print(datetime.now()) + timedelta(7)
#print(datetime.now().strftime('%a'))
#data = 'Jun 1 2005'
#print(datetime.strptime(data, '%b/%d/%y'))



cadastro = [{'nome':'vitor','email':'vitor@vitor'},{'nome': 'cesar', 'email': 'cesar'}]
print(len(cadastro))
cadastro[2]['nome':' pires']['email':['pires@pires']]
print(cadastro[1])