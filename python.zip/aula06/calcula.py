def soma(a,b):
    return a +b

def sub(a,b):
    return a-b

def divi(a,b):
    return a/b

def mult(a,b):
    return a*b