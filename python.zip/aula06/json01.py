import json
aluno ={
        'nome':'Vitor',
        'curso':'python'
    }
print(type(json.dumps(aluno))
string= json.dumps(aluno)
print(type(json.dumps(aluno))

print(type(json.loads(string)))