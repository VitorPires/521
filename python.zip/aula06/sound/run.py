from effects.echo import effect_echo
from formats.wavread import format_wavread
print(effect_echo())
print(format_wavread())
