def format_wavread():
    return 'Funcao waveread'

