def effect_echo():
    return 'Funcao effect echo'